﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAccess
{
    public class DAConexion
    {
        public SqlConnection Conexion()
        {
            SqlConnection conexion;
            conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["ConexionBD"].ToString());
            return @conexion;
        }
    }
}
