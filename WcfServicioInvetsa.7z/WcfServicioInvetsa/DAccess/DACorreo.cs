﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;


namespace DAccess
{
    public class DACorreo
    {

        public void Proceso_ObtenerContenidoCorreo(ref BEEmail email, ref string ErrorContenidoCorreo, string tipo)
        {
            string Contenido = string.Empty;
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            conn = conectar.Conexion();
            try
            {
                DataTable dt = new DataTable();
                using (SqlCommand cmd = new SqlCommand("Proceso_ObtenerContenidoCorreo", conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@docEntry", email.Param);
                    cmd.Parameters.AddWithValue("@tipo", tipo);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                email.Asunto = Convert.ToString(reader["Asunto"]);
                                email.Destino = Convert.ToString(reader["Para"]);
                                email.Copia = Convert.ToString(reader["Copia"]);
                                email.Contenido = Convert.ToString(reader["Contenido"]);
                                email.Cliente = Convert.ToString(reader["Cliente"]);   
                            }
                        }
                    }                  
                }
            }
            catch (Exception ex)
            {
                conn.Close();
                ErrorContenidoCorreo = ex.Message.ToString();
            }
            finally
            {
                conn.Close();
            }

            
        }


        public List<BEDocumento> Proceso_ObtenerCasosEnvioCorreo(string tipo, ref string Error)
        {
            List<BEDocumento> Lista = new List<BEDocumento>();           
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            conn = conectar.Conexion();
            try
            {
                DataTable dt = new DataTable();  
                using (SqlCommand cmd = new SqlCommand("Proceso_ObtenerCasosEnvioCorreo", conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;                 
                    cmd.Parameters.AddWithValue("@tipo", tipo);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                BEDocumento d = new BEDocumento();
                                d.DocEntry = Convert.ToInt32(reader["DocEntry"]);                               
                                Lista.Add(d);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                conn.Close();
                Error= ex.Message.ToString();
            }
            finally
            {
                conn.Close();
            }

            return Lista;
        }


        public void ActualizarPostEnvioCorreo(BEEmail email, string tipo, ref string ErrorActualizarPostEnvioCorreo, int DocEntry) {

            string U_MSS_NOMARC = string.Empty;
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            conn = conectar.Conexion();
            try
            {
                using (SqlCommand cmd = new SqlCommand("Proceso_ActualizarPostEnvioCorreo", conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@docEntry", DocEntry);
                    cmd.Parameters.AddWithValue("@tipo", tipo);
                    cmd.Parameters.AddWithValue("@Asunto", email.Asunto);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                conn.Close();
                ErrorActualizarPostEnvioCorreo = ex.Message.ToString();                 
            }
            finally
            {
                conn.Close();
            }

            
        }
    }
}
