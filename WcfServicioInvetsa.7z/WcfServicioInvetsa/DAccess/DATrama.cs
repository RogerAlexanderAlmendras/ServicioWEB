﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;

namespace DAccess
{
    public class DATrama
    {
        public DataTable ObtenerDatosDocEntry(BEDocumento obj, ref string ErrorObtenerDatosDocEntry)
        {
            string procedure = String.Empty;
            DataTable dt = new DataTable();
            DAConexion conectar = new DAConexion();
            SqlConnection conn;

            conn = conectar.Conexion();
            if (obj.ObjType == 17)
            {
                procedure = "INV_ProcesoSignia_OrdenVentaORD000025";
            }
            if (obj.ObjType == 18)
            {
                procedure = "INV_ProcesoSignia_FacturaReservaINGPRVWTXT";
            }
            else if (obj.ObjType == 22)
            {
                procedure = "INV_ProcesoSignia_OrdenCompraINGPRVWTXT";
            }
            else if (obj.ObjType == 60)
            {
                procedure = "INV_ProcesoSignia_SalidaMercanciaORD000025";
            }
            else if (obj.ObjType == 67)
            {
                procedure = "INV_ProcesoSignia_TransferenciaStockORD000025";
            }

            try
            {
                using (SqlCommand cmd = new SqlCommand(procedure, conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@DocEntry", SqlDbType.Int);
                    cmd.Parameters["@DocEntry"].Value = obj.DocEntry;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                ErrorObtenerDatosDocEntry = ex.ToString();
                conn.Close();
            }
            finally
            {
                conn.Close();

            }
            return dt;

        }

        public DataTable TraerResultado(string Ejecucion_Query, ref string ErrorMensaje)
        {
            DataTable dt = new DataTable();
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            try
            {
                conn = conectar.Conexion();
                SqlCommand cmd = new SqlCommand(Ejecucion_Query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception m)
            {
                ErrorMensaje = m.Message;

            }

            return dt;

        }

        public List<BEDocumento> ListarDocEntry(int indicador, ref string ErrorListarDocEntry)
        {
            List<BEDocumento> Lista = new List<BEDocumento>();
            DAConexion conectar = new DAConexion();

            SqlConnection conn;
            conn = conectar.Conexion();
            SqlCommand cmd = new SqlCommand("INV_ProcesoSignia_ListadoDocumentosFTP", conn);
            try
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@indicador", indicador);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            BEDocumento d = new BEDocumento();
                            d.DocEntry = Convert.ToInt32(reader["DocEntry"]);
                            d.ObjType = Convert.ToInt32(reader["ObjType"]);
                            Lista.Add(d);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorListarDocEntry = ex.Message.ToString();
                conn.Close();
                cmd.Dispose();
            }
            finally
            {
                conn.Close();
                cmd.Dispose();
            }
            return Lista;

        }


        public string Actualizar_U_MSS_NOMARC(BEDocumento obj, ref string Error_U_MSS_NOMARC)
        {
            string U_MSS_NOMARC = string.Empty;
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            conn = conectar.Conexion();
            try
            {
                using (SqlCommand cmd = new SqlCommand("INV_ProcesoSignia_Actualizar_U_MSS_NOMARC", conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@DocEntry", SqlDbType.Int);
                    cmd.Parameters.Add("@ObjType", SqlDbType.Int);
                    cmd.Parameters.Add("@U_MSS_NOMARC", SqlDbType.NVarChar, 50).Direction = ParameterDirection.Output;
                    cmd.Parameters["@DocEntry"].Value = obj.DocEntry;
                    cmd.Parameters["@ObjType"].Value = obj.ObjType;
                    cmd.ExecuteNonQuery();
                    U_MSS_NOMARC = Convert.ToString(cmd.Parameters["@U_MSS_NOMARC"].Value);
                }
            }
            catch (Exception ex)
            {
                conn.Close();
                Error_U_MSS_NOMARC =  ex.Message.ToString();                
            }
            finally
            {
                conn.Close();
            }

            return U_MSS_NOMARC;
        }


        public void ActualizarEnvioFTPDocEntry(BEDocumento obj, ref string ErrorActualizar)
        {            
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            conn = conectar.Conexion();
            try {
                using (SqlCommand cmd = new SqlCommand("INV_ProcesoSignia_ActualizarEnvioFTPDocEntry", conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DocEntry", obj.DocEntry);
                    cmd.Parameters.AddWithValue("@ObjType", obj.ObjType);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex) {

                ErrorActualizar = ex.Message.ToString();
                conn.Close();
            }
            finally {
                conn.Close();
            }
           
            
        }


        public BEEmail ObtenerDatosEnvioCorreo(BEDocumento obj)
        {
            BEEmail email = new BEEmail();
            string asunto = string.Empty;
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            conn = conectar.Conexion();
            try
            {
                DataTable dt = new DataTable();

                using (SqlCommand cmd = new SqlCommand("INV_ProcesoFTP_DatosEnvioCorreo", conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DocEntry", obj.DocEntry);
                    cmd.Parameters.AddWithValue("@ObjType", obj.ObjType);
                    cmd.ExecuteNonQuery();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    email.Asunto = dt.Rows[0]["ASUNTO"].ToString();
                    email.Destino = dt.Rows[0]["DESTINO"].ToString();
                    email.Copia = dt.Rows[0]["COPIA"].ToString();
                    //email.Contenido = dt.Rows[0]["CONTENIDO"].ToString();
                }
            }
            catch (Exception m)
            {
                conn.Close();
                Console.WriteLine(m.Message);
            }
            finally
            {
                conn.Close();
            }
            return email;

        }


        public void ProcesoSigniaActualizarEnviadosFTP(DataTable dt, string tipo, ref string ErrorActualizarEnvioFtp)
        {

            string valor = string.Empty;
            DAConexion conectar = new DAConexion();
            SqlConnection conn;
            conn = conectar.Conexion();

            try
            {   
                using (SqlCommand cmd = new SqlCommand("INV_ProcesoSignia_ActualizarEnvioFTPMasivo", conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Tipo", tipo);               
                    cmd.ExecuteNonQuery();
                }               
            }
            catch (Exception ex)
            {
                ErrorActualizarEnvioFtp = ex.Message.ToString();
                conn.Close();
            }
            finally
            {
                conn.Close();
            }
        }



        public List<BEArchivos> ObtenerArchivosAdjuntar(BEDocumento obj, ref string ErrorAdjuntar)
        {
            List<BEArchivos> Lista = new List<BEArchivos>();
            DAConexion conectar = new DAConexion();
            DataTable dt = new DataTable();
            SqlConnection conn;
           
            conn = conectar.Conexion();
            SqlCommand cmd = new SqlCommand("INV_ProcesoSignia_ObtenerArchivosAdjuntar", conn);
            try
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DocEntry", obj.DocEntry);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            BEArchivos d = new BEArchivos();
                            d.Nombre = Convert.ToString(reader["NombreArchivo"]);
                            d.Ruta =  Convert.ToString(reader["RutaArchivo"]);
                            d.RutaCompleta = Convert.ToString(reader["RutaCompleta"]);
                            Lista.Add(d);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorAdjuntar = ex.ToString();
                conn.Close();
                cmd.Dispose();
            }
            finally
            {
                conn.Close();
                cmd.Dispose();
            }
            return Lista;

        }


    }
}
