﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace BLBusiness
{
    public class BLUtil
    {
        //Borramos todos los archivos creados
        void BorrarArchivosDirectorio(string pathLocalOutput)
        {

            List<string> strFiles = Directory.GetFiles(pathLocalOutput, "*", SearchOption.AllDirectories).ToList();

            foreach (string fichero in strFiles)
            {
                File.Delete(fichero);
            }
        }

        public static void UploadFileToFtp(string pathLocalOutput, string NombreArchivo)
        {
            string userName = WebConfigurationManager.AppSettings["userName"].ToString();
            string passName = WebConfigurationManager.AppSettings["passName"].ToString();
            string ftp = WebConfigurationManager.AppSettings["ftp"].ToString() + NombreArchivo;

            using (var client = new WebClient())
            {
                client.Credentials = new NetworkCredential(userName, passName);
                string ArchivoCopiar = pathLocalOutput + NombreArchivo;
                client.UploadFile(ftp, WebRequestMethods.Ftp.UploadFile, ArchivoCopiar);
            }
        }

        public void GenerarTXT(DataTable dt, string pathLocalOutput, string nombre)
        {
            string ArchivoGrabarTxt = pathLocalOutput + nombre;
            using (StreamWriter file = new StreamWriter(ArchivoGrabarTxt, true))
            {
                foreach (DataRow row in dt.Rows)
                {
                    List<string> items = new List<string>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        items.Add(row[col.ColumnName].ToString());
                    }
                    string linea = string.Join("", items.ToArray()).ToUpper();

                    if (linea.Trim() != "")
                    {
                        string TextoSinTildes = linea.Replace('Á', 'A').Replace('É', 'E').Replace('Í', 'I').Replace('Ó', 'O').Replace('Ú', 'U').Replace('°', 'C');
                        file.WriteLine(TextoSinTildes.TrimEnd());
                    }
                }
            }

        }
    }
}
