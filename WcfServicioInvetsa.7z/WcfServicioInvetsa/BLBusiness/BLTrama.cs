﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAccess;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Configuration;
using Entity;
using System.Web;
using System.Web.Configuration;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;


namespace BLBusiness
{
    public class BLTrama
    {
        //------------------------------------------------------IDEX-----------------------------------------------------------

        public BERespuesta Idex_ArchivosFTP(string FECHA_INI, string FECHA_FIN)
        {
            BERespuesta rpta = new BERespuesta();
            BLCorreo correo = new BLCorreo();
            List<BEMemory> ListaStream = new List<BEMemory>();
            BEDocumento obj = new BEDocumento();
            obj.DocEntry = 0;
            obj.ObjType = 999999;

            string ErrorEnvioSistemas = string.Empty;
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorUpload = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string mensajeSalida = string.Empty;
            string ArchivosGenerados = string.Empty;
            string ArchivosGeneradosHTML = string.Empty;
            string ListaProceduresIdex = string.Empty;
            string NombreArchivo = string.Empty;           
            string NombreProcedure = string.Empty;
            ListaProceduresIdex = WebConfigurationManager.AppSettings["ListaProceduresIdex"].ToString();
            string Ejecucion_Query = string.Empty;
            bool flatIngreso = false;
            string AgregarMensajeBody = "Parámetros para Idex : Fecha Desde: " + FECHA_INI + " Fecha Hasta: " + FECHA_FIN;
            string[] procedure_ = ListaProceduresIdex.Split(',');

            try
            {

                for (int i = 0; i < procedure_.Length; i++)
                {
                    NombreProcedure = procedure_[i].ToString();

                    if (NombreProcedure.Contains('_'))
                    {
                        string[] words = NombreProcedure.Split('_');
                        NombreArchivo = words[2].ToString();
                    }

                    Ejecucion_Query = NombreProcedure + " " + FECHA_INI + ", " + FECHA_FIN;

                    DataTable dt = new DataTable();
                    string ErrorMensaje = string.Empty;
                    dt = TraerResultado(Ejecucion_Query, ref ErrorMensaje);
                    if (ErrorMensaje.Length > 0)
                    {
                        rpta.Codigo = 1;
                        rpta.Mensaje = "Error TraerResultado: " + ErrorMensaje;
                        return rpta;
                    }

                    if (dt.Rows.Count > 0)
                    {
                        flatIngreso = true;
                        string fecha = DateTime.Now.ToString("yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                        NombreArchivo = "ACC_" + NombreArchivo + "_" + fecha + ".txt";
                        MemoryStream memStream = new MemoryStream();
                        string ErrorTXT_Memoria = string.Empty;
                        GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                        if (ErrorTXT_Memoria.Length > 0)
                        {                            
                            rpta.Codigo = 1;
                            rpta.Mensaje ="Error proceso ErrorTXT_Memoria: " + ErrorTXT_Memoria;
                            return rpta;
                        }

                        UploadStreamIdex(memStream, NombreArchivo, ref ErrorUpload);
                        BEMemory memory = new BEMemory();
                        memory.Memoria = memStream;
                        memory.NombreArchivo = NombreArchivo;
                        ListaStream.Add(memory);
                        if (ErrorUpload.Length > 0)
                        {
                            rpta.Codigo = 1;
                            rpta.Mensaje ="Error en insertar documento al FTP: " + ErrorUpload;
                            return rpta;
                        }
                        memStream.Dispose();
                        memStream.Close();
                        ArchivosGenerados = NombreArchivo + ", " + ArchivosGenerados;
                        ArchivosGeneradosHTML = ArchivosGeneradosHTML + "<b> * " + NombreArchivo + "</b>" + "<br/>";
                    }
                }

                if (flatIngreso)
                {
                    ArchivosGenerados = ArchivosGenerados.Trim().Remove(ArchivosGenerados.Trim().Length - 1);
                    mensajeSalida = "IDEX: Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp : " + ArchivosGenerados;
                    AgregarMensajeBody = "IDEX: Operación completada con éxito. Fecha de Consulta Desde: <b>" + FECHA_INI + "</b> Hasta: <b>" + FECHA_FIN + "</b><br/> Se ha generado archivo(s) de texto en el ftp : <br/><br/>" + ArchivosGeneradosHTML;
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {                        
                        rpta.Codigo = 1;
                        rpta.Mensaje = mensajeSalida + ". No se pudo enviar correo de confirmación: " + ErrorEnvioEmail;
                        return rpta;
                    }

                }
                else
                {
                    rpta.Codigo = 1;
                    rpta.Mensaje = "No se encontraron datos para la consulta: " + mensajeSalida;
                    return rpta;                    
                }

                rpta.Codigo = 2;
                rpta.Mensaje = mensajeSalida;
                return rpta;

            }
            catch (Exception e)
            {
                rpta.Codigo = 1;
                rpta.Mensaje = "Error Exception: " + e.Message.ToString();
                return rpta;
            }
        }


        //------------------------------------------------------SIGNIA---------------------------------------------------------


        public BERespuesta Signia_MaestrosFtp()
        {
            BLCorreo correo = new BLCorreo();

            List<BEMemory> ListaStream = new List<BEMemory>();
            BERespuesta res = new BERespuesta();
            string ListaProcedures = string.Empty;
            ListaProcedures = WebConfigurationManager.AppSettings["ListaProcedures"].ToString();

            BEDocumento obj = new BEDocumento();
            obj.DocEntry = 0;
            obj.ObjType = 888888;
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string AgregarMensajeBody = string.Empty;
            string mensajeSalida = string.Empty;
            string ArchivosGenerados = string.Empty;
            string ArchivosGeneradosHTML = string.Empty;
            string FechaActual = string.Empty;
            string HoraActual = string.Empty;
            string NombreArchivo = string.Empty;           
            string NombreProcedure = string.Empty;
            string tipo = string.Empty;
            string ErrorActualizarEnvioFtp = string.Empty;
            bool flatIngreso = false;
            FechaActual = DateTime.Today.ToString("yyyyMMdd");
            HoraActual = DateTime.Now.ToString("HHmmss");
            try
            {

                string[] procedure_ = ListaProcedures.Split(',');

                for (int i = 0; i < procedure_.Length; i++)
                {
                    NombreProcedure = procedure_[i].ToString();
                    if (NombreProcedure.Contains('_'))
                    {
                        string[] words = NombreProcedure.Split('_');
                        NombreArchivo = words[2].ToString();
                        tipo = NombreArchivo;
                    }

                    DataTable dt = new DataTable();
                    string ErrorMensaje = string.Empty;
                    dt = TraerResultado("exec " + NombreProcedure, ref ErrorMensaje);

                    if (ErrorMensaje.Length > 0)
                    {
                        res.Mensaje = "Error en Traer Datos : " + ErrorMensaje;
                        res.Codigo = 1;
                        return res;
                    }

                    if (dt.Rows.Count > 0)
                    {
                        flatIngreso = true;
                        NombreArchivo = NombreArchivo + "_INV" + FechaActual + "_" + HoraActual + ".txt";
                        MemoryStream memStream = new MemoryStream();
                        string ErrorTXT_Memoria = string.Empty;
                        GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                        if (ErrorTXT_Memoria.Length > 0)
                        {
                            res.Mensaje = "Error proceso ErrorTXT_Memoria : " + ErrorTXT_Memoria;
                            res.Codigo = 1;
                            return res;
                        }
                        string ErrorUpload = string.Empty;
                        UploadStream(memStream, NombreArchivo, ref ErrorUpload);

                        BEMemory memory = new BEMemory();
                        memory.Memoria = memStream;
                        memory.NombreArchivo = NombreArchivo;
                        ListaStream.Add(memory);
                        if (ErrorUpload.Length > 0)
                        {
                            res.Mensaje = "Error en insertar documento al FTP : " + ErrorUpload;
                            res.Codigo = 1;
                            return res;
                        }
                        memStream.Dispose();
                        memStream.Close();
                        ArchivosGenerados = NombreArchivo + ", " + ArchivosGenerados;
                        ArchivosGeneradosHTML = ArchivosGeneradosHTML + "<b> * " + NombreArchivo + "</b>" + "<br/>";
                        //Actualizar los DocEntry enviados al ftp con el indicador de envio
                        DATrama da = new DATrama();
                        da.ProcesoSigniaActualizarEnviadosFTP(dt, tipo, ref ErrorActualizarEnvioFtp);
                        if (ErrorActualizarEnvioFtp.Length > 0)
                        {
                            //string asunto = "Error: " + System.Reflection.MethodBase.GetCurrentMethod().Name;
                            //correo.EnviarCorreoSistemas(asunto, ErrorActualizarEnvioFtp);
                            res.Mensaje = "Error en actualizar el envio al ftp en la bd: " + ErrorActualizarEnvioFtp;
                            res.Codigo = 1;
                            return res;
                        }

                    }
                }

                if (flatIngreso)
                {
                    ArchivosGenerados = ArchivosGenerados.Trim().Remove(ArchivosGenerados.Trim().Length - 1);
                    mensajeSalida = "Signia : Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp : " + ArchivosGenerados;
                    res.Codigo = 2;
                    AgregarMensajeBody = "Signia : Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp : <br/><br/>" + ArchivosGeneradosHTML;
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {
                        res.Mensaje = "No se pudo enviar correo de confirmación: " + ErrorEnvioEmail;
                        res.Codigo = 1;
                        return res;
                    }
                }
                else
                {
                    res.Mensaje = "No se encontraron datos para la consulta";
                    res.Codigo = 1;
                    return res;
                }

                res.Codigo = 2;
                res.Mensaje = mensajeSalida;
                return res;

            }
            catch (Exception e)
            {
                res.Mensaje = e.Message.ToString();
                res.Codigo = 1;
                return res;
            }
        }


        //Nuevo Cliente signia - ESTTXT, RCMTXT, (opcional RCMANXTXT)
        public BERespuesta2 SigniaNuevoClienteFtp(BEDocumento obj, ref int ArchivosGenerados, ref string CasosNoGenerados, ref string AcumuladorMensajes)
        {
            List<BEMemory> ListaStream = new List<BEMemory>();
            BERespuesta2 res = new BERespuesta2();
            string ListaProcedures = string.Empty;
            ListaProcedures = WebConfigurationManager.AppSettings["ListaProcedures2"].ToString();//******           
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string AgregarMensajeBody = string.Empty;
            string mensajeSalida = string.Empty;
            string FechaActual = string.Empty;
            string HoraActual = string.Empty;
            string NombreArchivo = string.Empty;
            string ErrorActualizar = string.Empty;
            string NombreProcedure = string.Empty;
            

            FechaActual = DateTime.Today.ToString("yyyyMMdd");
            HoraActual = DateTime.Now.ToString("HHmmss");
            try
            {
                string[] procedure_ = ListaProcedures.Split(',');

                for (int i = 0; i < procedure_.Length; i++)
                {
                    NombreProcedure = procedure_[i].ToString();
                    if (NombreProcedure.Contains('_'))
                    {
                        string[] words = NombreProcedure.Split('_');
                        NombreArchivo = words[2].ToString();
                    }

                    DataTable dt = new DataTable();
                    string ErrorMensaje = string.Empty;
                    dt = TraerResultado("exec " + NombreProcedure + " " + obj.DocEntry, ref ErrorMensaje);
                    if (ErrorMensaje.Length > 0)
                    {                      
                        AcumuladorMensajes = AcumuladorMensajes + ErrorMensaje;
                        return res;
                    }

                    if (dt.Rows.Count > 0)
                    {
                        NombreArchivo = NombreArchivo + "_INV" + FechaActual + "_" + HoraActual + ".txt";
                        MemoryStream memStream = new MemoryStream();
                        string ErrorTXT_Memoria = string.Empty;
                        GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                        if (ErrorTXT_Memoria.Length > 0)
                        {
                            CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                          
                            AcumuladorMensajes = AcumuladorMensajes + ErrorTXT_Memoria;
                            return res;
                        }
                        string ErrorUpload = string.Empty;
                        UploadStream(memStream, NombreArchivo, ref ErrorUpload);
                        BEMemory memory = new BEMemory();
                        memory.Memoria = memStream;
                        memory.NombreArchivo = NombreArchivo;
                        ListaStream.Add(memory);
                        if (ErrorUpload.Length > 0)
                        {
                            CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                         
                            AcumuladorMensajes = AcumuladorMensajes + ErrorUpload;
                            return res;
                        }
                        memStream.Dispose();
                        memStream.Close();
                        ArchivosGenerados++;
                        ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
                        if (ErrorActualizar.Length > 0)
                        {
                            AcumuladorMensajes = AcumuladorMensajes + ErrorActualizar;
                            return res;
                        }
                        AgregarMensajeBody = "Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp: " + "<b>" + NombreArchivo + "</b>" + " correctamente para el DocEntry: " + "<b>" + obj.DocEntry + "</b>";
                        EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                        if (ErrorEnvioEmail.Length > 0)
                        {                           
                            AcumuladorMensajes = AcumuladorMensajes + ErrorEnvioEmail;
                            return res;
                        }
                    }
                    else
                    {
                        //casos no generados
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                    }
                }
                             
                return res;
            }
            catch (Exception e)
            {               
                AcumuladorMensajes = AcumuladorMensajes + e.Message.ToString();               
                return res;
            }
        }

        //Nuevo Puntos entrega signia - ESTTXT
        public BERespuesta2 SigniaNuevoPuntoEntrega_ESTTXT(BEDocumento obj, ref int ArchivosGenerados, ref string CasosNoGenerados, ref string AcumuladorMensajes)
        {
            List<BEMemory> ListaStream = new List<BEMemory>();
            BERespuesta2 res = new BERespuesta2();
            string NombreProcedure = WebConfigurationManager.AppSettings["ListaProcedures3"].ToString();//******           
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string AgregarMensajeBody = string.Empty;
            string mensajeSalida = string.Empty;
            string FechaActual = string.Empty;
            string HoraActual = string.Empty;
            string NombreArchivo = string.Empty;
            string ErrorActualizar = string.Empty;
            FechaActual = DateTime.Today.ToString("yyyyMMdd");
            HoraActual = DateTime.Now.ToString("HHmmss");
            try
            {

                if (NombreProcedure.Contains('_'))
                {
                    string[] words = NombreProcedure.Split('_');
                    NombreArchivo = words[2].ToString();
                }

                DataTable dt = new DataTable();
                string ErrorMensaje = string.Empty;
                dt = TraerResultado("exec " + NombreProcedure + " " + obj.DocEntry, ref ErrorMensaje);

                if (ErrorMensaje.Length > 0)
                {                   
                    AcumuladorMensajes = AcumuladorMensajes + ErrorMensaje;
                    return res;
                }

                if (dt.Rows.Count > 0)
                {
                    NombreArchivo = NombreArchivo + "_INV" + FechaActual + "_" + HoraActual + ".txt";
                    MemoryStream memStream = new MemoryStream();
                    string ErrorTXT_Memoria = string.Empty;
                    GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                    if (ErrorTXT_Memoria.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorTXT_Memoria;
                        return res;
                    }
                    string ErrorUpload = string.Empty;
                    UploadStream(memStream, NombreArchivo, ref ErrorUpload);
                    BEMemory memory = new BEMemory();
                    memory.Memoria = memStream;
                    memory.NombreArchivo = NombreArchivo;
                    ListaStream.Add(memory);
                    if (ErrorUpload.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                        AcumuladorMensajes = AcumuladorMensajes + ErrorUpload;                                               
                        return res;
                    }
                    memStream.Dispose();
                    memStream.Close();
                    ArchivosGenerados++;
                    ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
                    if (ErrorActualizar.Length > 0)
                    {
                        AcumuladorMensajes = AcumuladorMensajes + ErrorActualizar;
                        return res;
                    }
                    AgregarMensajeBody = "Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp: " + "<b>" + NombreArchivo + "</b>" + " correctamente para el DocEntry: " + "<b>" + obj.DocEntry + "</b>";
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {
                        AcumuladorMensajes = AcumuladorMensajes + ErrorEnvioEmail;                       
                        return res;
                    }
                }
              
                return res;
            }
            catch (Exception e)
            {               
                AcumuladorMensajes = AcumuladorMensajes + e.Message.ToString();               
                return res;
            }
        }

        //Nuevo Producto signia - IIMTXT
        public BERespuesta2 SigniaNuevoProducto_IIMTXT(BEDocumento obj, ref int ArchivosGenerados, ref string CasosNoGenerados, ref string AcumuladorMensajes)
        {
            List<BEMemory> ListaStream = new List<BEMemory>();
            BERespuesta2 res = new BERespuesta2();
            string NombreProcedure = WebConfigurationManager.AppSettings["ListaProcedures4"].ToString();//******

            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string AgregarMensajeBody = string.Empty;
            string mensajeSalida = string.Empty;
            string FechaActual = string.Empty;
            string HoraActual = string.Empty;
            string NombreArchivo = string.Empty;
            string ErrorActualizar = string.Empty;

            FechaActual = DateTime.Today.ToString("yyyyMMdd");
            HoraActual = DateTime.Now.ToString("HHmmss");
            try
            {
                //string[] procedure_ = ListaProcedures.Split(',');

                //for (int i = 0; i < procedure_.Length; i++)
                //{
                //    NombreProcedure = procedure_[i].ToString();
                if (NombreProcedure.Contains('_'))
                {
                    string[] words = NombreProcedure.Split('_');
                    NombreArchivo = words[2].ToString();
                }

                DataTable dt = new DataTable();
                string ErrorMensaje = string.Empty;
                dt = TraerResultado("exec " + NombreProcedure + " " + obj.DocEntry, ref ErrorMensaje);
                if (ErrorMensaje.Length > 0)
                {                  
                    AcumuladorMensajes = AcumuladorMensajes + ErrorMensaje;
                    return res;
                }

                if (dt.Rows.Count > 0)
                {
                    NombreArchivo = NombreArchivo + "_INV" + FechaActual + "_" + HoraActual + ".txt";
                    MemoryStream memStream = new MemoryStream();
                    string ErrorTXT_Memoria = string.Empty;
                    GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                    if (ErrorTXT_Memoria.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                     
                        AcumuladorMensajes = AcumuladorMensajes + ErrorTXT_Memoria;
                        return res;
                    }
                    string ErrorUpload = string.Empty;
                    UploadStream(memStream, NombreArchivo, ref ErrorUpload);
                    BEMemory memory = new BEMemory();
                    memory.Memoria = memStream;
                    memory.NombreArchivo = NombreArchivo;
                    ListaStream.Add(memory);
                    if (ErrorUpload.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorUpload;
                        return res;
                    }

                    memStream.Dispose();
                    memStream.Close();
                    ArchivosGenerados++;
                    ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
                    if (ErrorActualizar.Length > 0)
                    {
                        AcumuladorMensajes = AcumuladorMensajes + ErrorActualizar;
                        return res;
                    }
                    AgregarMensajeBody = "Signia : Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp:" + NombreArchivo + " correctamente para el DocEntry: " + obj.DocEntry;
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {                    
                        AcumuladorMensajes = AcumuladorMensajes + ErrorEnvioEmail;
                        return res;
                    }
                }
                else
                {
                    //casos no generados
                    CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                }
            
                return res;
              
            }
            catch (Exception e)
            {               
                AcumuladorMensajes = AcumuladorMensajes + e.Message.ToString();               
                return res;
            }
        }





        public BERespuesta2 PlantillaIngreso_INGPRVW(BEDocumento obj, ref int ArchivosGenerados, ref string CasosNoGenerados, ref string AcumuladorMensajes)
        {
            List<BEMemory> ListaStream = new List<BEMemory>();
            BERespuesta2 res = new BERespuesta2();
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string mensajeSalida = string.Empty;
            string Error_U_MSS_NOMARC = string.Empty;
            string ErrorActualizar = string.Empty;

            DataTable dt = new DataTable();
            try
            {
                dt = ObtenerDatosDocEntry(obj);

                if (dt.Rows.Count > 0)
                {
                    obj.U_mss_nomarc = Actualizar_U_MSS_NOMARC(obj, ref Error_U_MSS_NOMARC);// dejar como xls
                    if (Error_U_MSS_NOMARC.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + Error_U_MSS_NOMARC;
                        return res;
                    }

                    string NombreArchivo = "INGPRVWTXT_" + obj.U_mss_nomarc.Replace("xls", "txt");                  
                    string AgregarMensajeBody = "Parametros: DocEntry: " + obj.DocEntry + " Archivo : " + NombreArchivo;

                    MemoryStream memStream = new MemoryStream();
                    string ErrorTXT_Memoria = string.Empty;
                    GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                    if (ErrorTXT_Memoria.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorTXT_Memoria;
                        return res;
                    }
                    string ErrorUpload = string.Empty;
                    UploadStream(memStream, NombreArchivo, ref ErrorUpload);
                    BEMemory memory = new BEMemory();
                    memory.Memoria = memStream;
                    memory.NombreArchivo = NombreArchivo;
                    ListaStream.Add(memory);
                    if (ErrorUpload.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                      
                        AcumuladorMensajes = AcumuladorMensajes + ErrorUpload;
                        return res;
                    }

                    memStream.Dispose();
                    memStream.Close();
                    ArchivosGenerados++;
                    ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
                    if (ErrorActualizar.Length > 0)
                    {
                        AcumuladorMensajes = AcumuladorMensajes + ErrorActualizar;
                        return res;
                    }
                    AgregarMensajeBody = "Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp: " + "<b>" + NombreArchivo + "</b>" + " correctamente para el DocEntry: " + "<b>" + obj.DocEntry + "</b>";
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorEnvioEmail;
                        return res;
                    }

                }
                else
                {
                    //casos no generados
                    CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                }
             
                return res;
            }
            catch (Exception e)
            {                
                AcumuladorMensajes = AcumuladorMensajes + e.Message.ToString();                
                return res;
            }

        }


        public BERespuesta2 PlantillaAtencionPedidos_ORD(BEDocumento obj, ref int ArchivosGenerados, ref string CasosNoGenerados, ref string AcumuladorMensajes)
        {           
            List<BEMemory> ListaStream = new List<BEMemory>();          
            BERespuesta2 res = new BERespuesta2();
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string mensajeSalida = string.Empty;
            string Error_U_MSS_NOMARC = string.Empty;
            string ErrorActualizar = string.Empty;

            DataTable dt = new DataTable();
            try
            {
                dt = ObtenerDatosDocEntry(obj);
                if (dt.Rows.Count > 0)
                {
                    obj.U_mss_nomarc = Actualizar_U_MSS_NOMARC(obj, ref Error_U_MSS_NOMARC);// dejar como xls
                    if (Error_U_MSS_NOMARC.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                        AcumuladorMensajes = AcumuladorMensajes + Error_U_MSS_NOMARC;
                        return res;
                    }
                    string NombreArchivo = "ORD000025_" + obj.U_mss_nomarc;
                    string AgregarMensajeBody = "Parametros: DocEntry: " + obj.DocEntry + " Archivo : " + NombreArchivo;
                    MemoryStream memStream = new MemoryStream();
                    string ErrorTXT_Memoria = string.Empty;
                    GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                    if (ErrorTXT_Memoria.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                      
                        AcumuladorMensajes = AcumuladorMensajes + ErrorTXT_Memoria;
                        return res;
                    }
                    string ErrorUpload = string.Empty;
                    UploadStream(memStream, NombreArchivo, ref ErrorUpload);
                    BEMemory memory = new BEMemory();
                    memory.Memoria = memStream;
                    memory.NombreArchivo = NombreArchivo;
                    ListaStream.Add(memory);
                    if (ErrorUpload.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorUpload;
                        return res;
                    }

                    memStream.Dispose();
                    memStream.Close();
                    ArchivosGenerados++;
                    ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
                    if (ErrorActualizar.Length > 0)
                    {
                        AcumuladorMensajes = AcumuladorMensajes + ErrorActualizar;
                        return res;
                    }
                    AgregarMensajeBody = "Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp: " + "<b>" + NombreArchivo + "</b>" + " correctamente para el DocEntry: " + "<b>" + obj.DocEntry + "</b>";
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorEnvioEmail;
                        return res;
                    }
                }
                else
                {
                    //casos no generados
                    CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                }
               
                return res;
            }
            catch (Exception e)
            {              
                AcumuladorMensajes = AcumuladorMensajes + e.Message.ToString();               
                return res;
            }
        }


        public BERespuesta2 SalidaMercancias_ORD(BEDocumento obj, ref int ArchivosGenerados, ref string CasosNoGenerados, ref string AcumuladorMensajes)
        {           
            List<BEMemory> ListaStream = new List<BEMemory>();            
            BERespuesta2 res = new BERespuesta2();
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string mensajeSalida = string.Empty;
            string Error_U_MSS_NOMARC = string.Empty;
            string ErrorActualizar = string.Empty;

            DataTable dt = new DataTable();
            try
            {
                dt = ObtenerDatosDocEntry(obj);
                if (dt.Rows.Count > 0)
                {
                    obj.U_mss_nomarc = Actualizar_U_MSS_NOMARC(obj, ref Error_U_MSS_NOMARC);// dejar como xls
                    if (Error_U_MSS_NOMARC.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                        AcumuladorMensajes = AcumuladorMensajes + Error_U_MSS_NOMARC;
                        return res;
                    }
                    string NombreArchivo = "ORD000025_" + obj.U_mss_nomarc;
                    string AgregarMensajeBody = "Parametros: DocEntry: " + obj.DocEntry + " Archivo : " + NombreArchivo;

                    MemoryStream memStream = new MemoryStream();
                    string ErrorTXT_Memoria = string.Empty;
                    GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                    if (ErrorTXT_Memoria.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorTXT_Memoria;
                        return res;
                    }
                    string ErrorUpload = string.Empty;
                    UploadStream(memStream, NombreArchivo, ref ErrorUpload);
                    BEMemory memory = new BEMemory();
                    memory.Memoria = memStream;
                    memory.NombreArchivo = NombreArchivo;
                    ListaStream.Add(memory);
                    if (ErrorUpload.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorUpload;
                        return res;
                    }
                    memStream.Dispose();
                    memStream.Close();
                    ArchivosGenerados++;
                    ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
                    if (ErrorActualizar.Length > 0)
                    {
                        AcumuladorMensajes = AcumuladorMensajes + ErrorActualizar;
                        return res;
                    }
                    AgregarMensajeBody = "Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp: " + "<b>" + NombreArchivo + "</b>" + " correctamente para el DocEntry: " + "<b>" + obj.DocEntry + "</b>";
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorEnvioEmail;
                        return res;
                    }

                }
                else
                {
                    //casos no generados
                    CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                }
            
                return res;
            }
            catch (Exception e)
            {              
                AcumuladorMensajes = AcumuladorMensajes + e.Message.ToString();               
                return res;
            }
        }


        public BERespuesta2 TransferenciaStock_ORD(BEDocumento obj, ref int ArchivosGenerados, ref string CasosNoGenerados, ref string AcumuladorMensajes)
        {          
            List<BEMemory> ListaStream = new List<BEMemory>();           
            BERespuesta2 res = new BERespuesta2();
            string AvisoErrorPorCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;
            string mensajeSalida = string.Empty;
            string Error_U_MSS_NOMARC = string.Empty;
            string ErrorActualizar = string.Empty;

            DataTable dt = new DataTable();
            try
            {
                dt = ObtenerDatosDocEntry(obj);
                if (dt.Rows.Count > 0)
                {
                    obj.U_mss_nomarc = Actualizar_U_MSS_NOMARC(obj, ref Error_U_MSS_NOMARC);// dejar como xls
                    if (Error_U_MSS_NOMARC.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                        AcumuladorMensajes = AcumuladorMensajes + Error_U_MSS_NOMARC;
                        return res;
                    }
                    string NombreArchivo = "ORD000025_" + obj.U_mss_nomarc;
                    string AgregarMensajeBody = "Parametros: DocEntry: " + obj.DocEntry + " Archivo : " + NombreArchivo;

                    MemoryStream memStream = new MemoryStream();
                    string ErrorTXT_Memoria = string.Empty;
                    GenerarTXT_Memoria(dt, ref memStream, ref ErrorTXT_Memoria);
                    if (ErrorTXT_Memoria.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorTXT_Memoria;
                        return res;
                    }
                    string ErrorUpload = string.Empty;
                    UploadStream(memStream, NombreArchivo, ref ErrorUpload);
                    BEMemory memory = new BEMemory();
                    memory.Memoria = memStream;
                    memory.NombreArchivo = NombreArchivo;
                    ListaStream.Add(memory);
                    if (ErrorUpload.Length > 0)
                    {
                        CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";                       
                        AcumuladorMensajes = AcumuladorMensajes + ErrorUpload;
                        return res;
                    }
                    memStream.Dispose();
                    memStream.Close();
                    ArchivosGenerados++;
                    ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
                    if (ErrorActualizar.Length > 0)
                    {
                        AcumuladorMensajes = AcumuladorMensajes + ErrorActualizar;
                        return res;
                    }
                    AgregarMensajeBody = "Operación completada con éxito. Se ha generado archivo(s) de texto en el ftp: " + "<b>" + NombreArchivo + "</b>" + " correctamente para el DocEntry: " + "<b>" + obj.DocEntry + "</b>";
                    EnviarCorreoYAdjuntos_Maestros(obj, AgregarMensajeBody, ref ErrorEnvioEmail, AvisoErrorPorCorreo, ListaStream);
                    if (ErrorEnvioEmail.Length > 0)
                    {                     
                        AcumuladorMensajes = AcumuladorMensajes + ErrorEnvioEmail;
                        return res;
                    }
                }
                else
                {
                    //casos no generados
                    CasosNoGenerados = CasosNoGenerados + obj.DocEntry + ", ";
                }

                return res;
            }
            catch (Exception e)
            {               
                AcumuladorMensajes = AcumuladorMensajes + e.Message.ToString();
                return res;
            }
        }


        public DataTable ObtenerDatosDocEntry(BEDocumento obj)
        {
            string ErrorObtenerDatosDocEntry = String.Empty;
            DATrama da = new DATrama();
            DataTable dt = new DataTable();
            return da.ObtenerDatosDocEntry(obj, ref ErrorObtenerDatosDocEntry);           
        }


        public DataTable TraerResultado(string Ejecucion_Query, ref string ErrorMensaje)
        {            
            DATrama da = new DATrama();   
            return da.TraerResultado(Ejecucion_Query, ref ErrorMensaje);
        }
              

        public void GenerarTXT_Memoria(DataTable dt, ref MemoryStream memStream, ref string ErrorTXT_Memoria)
        {
            StreamWriter file = new StreamWriter(memStream, Encoding.UTF8);

            try
            {
                foreach (DataRow row in dt.Rows)
                {
                    List<string> items = new List<string>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        items.Add(row[col.ColumnName].ToString());
                    }
                    string linea = string.Join("", items.ToArray()).ToUpper();

                    if (linea.Trim() != "")
                    {
                        string TextoSinTildes = linea.Replace('Á', 'A').Replace('É', 'E').Replace('Í', 'I').Replace('Ó', 'O').Replace('Ú', 'U').Replace('°', 'C').Replace('Ñ', 'N').Replace('Ü', 'U').Replace("´", "'").Replace('¥', 'N').Replace('°', ' ').Replace('º', ' ').Replace('Ø', '0').Replace('|', ' ').Replace('"', ' ').Replace('{', ' ').Replace('}', ' ').Replace('[', ' ').Replace(']', ' ').Replace('*', ' ').Replace('?', ' ').Replace('¿', ' ').Replace('+', ' ').Replace('ª', ' ').Replace('á', ' ').Replace('®', ' ').Replace(' ', ' ');//¥ # %'(*+&)á® .Replace('#', 'N').Replace('&', 'Y').Replace('(', ' ').Replace(')', ' ')
                        TextoSinTildes = TextoSinTildes.Replace(System.Environment.NewLine, linea);
                        string output = Regex.Replace(TextoSinTildes, @"[^\u0009\u000A\u000D\u0020-\u007E]", " ");
                        file.WriteLine(output.TrimEnd());
                    }

                }

                file.Flush();
                memStream.Seek(0, SeekOrigin.Begin);
            }
            catch (Exception ex)
            {
                ErrorTXT_Memoria = ex.Message.ToString();               
            }
        }


        public List<BEDocumento> ListarDocEntry(int indicador, ref string ErrorListarDocEntry)
        {
            DATrama da = new DATrama();    
            return da.ListarDocEntry(indicador, ref ErrorListarDocEntry);           
        }

        
        public string Actualizar_U_MSS_NOMARC(BEDocumento obj,ref string Error_U_MSS_NOMARC)
        {        
            DATrama da = new DATrama();
            return da.Actualizar_U_MSS_NOMARC(obj, ref Error_U_MSS_NOMARC);            
        }
        public void ActualizarEnvioFTPDocEntry(BEDocumento obj, ref string ErrorActualizar)
        {
             DATrama da = new DATrama();
             da.ActualizarEnvioFTPDocEntry(obj, ref ErrorActualizar);
        }

        public BEEmail ObtenerDatosEnvioCorreo(BEDocumento obj)
        {
            DATrama da = new DATrama();
            return da.ObtenerDatosEnvioCorreo(obj);
        }
        
       

        public void EnviarCorreoYAdjuntos_Maestros(BEDocumento obj, string AgregarMensajeBody, ref string ErrorEnvioEmail, string AvisoErrorPorCorreo, List<BEMemory> ListaStream)
        {
            string passCredencial = WebConfigurationManager.AppSettings["passCredencial"].ToString();
            string host = WebConfigurationManager.AppSettings["host"].ToString();
            int puerto = Convert.ToInt16(WebConfigurationManager.AppSettings["puerto"]);

            string userCredencial = WebConfigurationManager.AppSettings["userCredencial"].ToString();
            string FechaHoraActual = DateTime.Today.ToString("dd/MM/yyyy");
            string HoraActual = DateTime.Now.ToString("HH:mm:ss");
            string asunto = string.Empty;
            BEEmail email = new BEEmail();
            try
            {
                email = ObtenerDatosEnvioCorreo(obj);
                if (AvisoErrorPorCorreo.Length > 0)
                {
                    asunto = AvisoErrorPorCorreo + " " + email.Asunto + " " + FechaHoraActual + " " + HoraActual;
                }
                else
                {
                    asunto = email.Asunto + " " + FechaHoraActual + " " + HoraActual;
                }
               
                SmtpClient client = new SmtpClient();
                client.Port = puerto;
                // utilizamos el servidor SMTP de gmail
                client.Host = host;
                client.EnableSsl = true;
                client.Timeout = 10000000; // (100000 = 100 segundos)
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                // nos autenticamos con nuestra cuenta de gmail
                client.Credentials = new NetworkCredential(userCredencial, passCredencial);
                string Contenido = string.Empty;
                                               
                Contenido = "<table align='left' style='max-width:100%;' width='auto'  height= 'auto'  border= '0px'    >";

                Contenido = Contenido + "<tr><td>";
                Contenido = Contenido + "<h3><p style='color:green;font-family:Sans-serif;margin-left:0.5em;'>" + "Notificaciones: Inversiones Veterinarias S.A: " + "  </p></h3> ";
                Contenido = Contenido + "<p style='margin-left:0.5em;'><font face='Sans-serif'>";
                Contenido = Contenido + AgregarMensajeBody +"</font><br/>";
                Contenido = Contenido + "Se adjunta los archivos correspondientes." + "<br/>";
                Contenido = Contenido + "Saludos cordiales, ";
                Contenido = Contenido + "</p>";
                Contenido = Contenido + "</td></td></tr>";

                Contenido = Contenido + "<tr><td style = 'text-align:left'>";
                Contenido = Contenido + "<img src='cid:imagen' style = 'max-width:30%;width:auto;height:auto;text-align:left;' />";
                Contenido = Contenido + "</td></tr>";
                Contenido = Contenido + "</table><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/> ";

                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(Contenido, Encoding.UTF8, MediaTypeNames.Text.Html);
                // Creamos el recurso a incrustar. Observad

                string FileName = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "imagenes\\logo_invetsa.png");
                LinkedResource img = new LinkedResource(FileName, MediaTypeNames.Image.Jpeg);
                img.ContentId = "imagen";
                //Lo incrustamos en la vista HTML...
                htmlView.LinkedResources.Add(img);


                MailMessage mail = new MailMessage(userCredencial, email.Destino, asunto, Contenido);
                //MailMessage mail = new MailMessage(userCredencial, "sistemas@invetsa.com", asunto, Contenido);
                mail.IsBodyHtml = true;
                mail.BodyEncoding = UTF8Encoding.UTF8;
                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                if (email.Copia.Length > 0)
                {
                    mail.To.Add(email.Copia);
                }

                //Adjuntamos loas archivos
                if (ListaStream.Count > 0)
                {
                    foreach (BEMemory l in ListaStream)
                    {
                        byte[] bytes = l.Memoria.ToArray();
                        l.Memoria.Close();
                        mail.Attachments.Add(new Attachment(new MemoryStream(bytes), l.NombreArchivo));
                    }
                }


                if (obj.ObjType == 18)
                {
                    List<BEArchivos> Lista = new List<BEArchivos>();
                    DATrama da = new DATrama();
                    //obj.DocEntry = 132792; 
                    string ErrorAdjuntar = string.Empty;
                    Lista = da.ObtenerArchivosAdjuntar(obj, ref ErrorAdjuntar);
                    if (ErrorAdjuntar.Length > 0)
                    {
                        ErrorEnvioEmail = ErrorAdjuntar;
                    }
                    else {
                        foreach (BEArchivos l in Lista)
                        {
                            //Attachment(@"\\SERVIDOR40\AnexosSAP\4013789 PL.PDF")
                            mail.Attachments.Add(new Attachment(l.RutaCompleta, MediaTypeNames.Application.Octet));                           
                        }
                    }                    
                }


                mail.AlternateViews.Add(htmlView);

                client.Send(mail);

            }
            catch (Exception ex)
            {                
                ErrorEnvioEmail = ErrorEnvioEmail + ex.Message.ToString();              
            }

        }

       
        public void UploadStream(MemoryStream stream, string NombreArchivo, ref string ErrorUpload)
        {

            string userName = WebConfigurationManager.AppSettings["userName"].ToString();
            string passName = WebConfigurationManager.AppSettings["passName"].ToString();
            string ftp = WebConfigurationManager.AppSettings["ftp"].ToString() + NombreArchivo;
            string rp = string.Empty;
            try
            {
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftp);
                request.Method = WebRequestMethods.Ftp.UploadFile;

                request.Credentials = new NetworkCredential(userName, passName);
                request.UsePassive = true;
                request.UseBinary = true;
                request.KeepAlive = true;
                request.Timeout = 600000;  // 10 minutos

                //StreamReader sourceStream = new StreamReader(stream);
                StreamReader reader = new StreamReader(stream, System.Text.Encoding.UTF8, true);
                byte[] fileContents = Encoding.UTF8.GetBytes(reader.ReadToEnd());
                reader.Close();
                request.ContentLength = fileContents.Length;

                Stream requestStream = request.GetRequestStream();
                requestStream.Write(fileContents, 0, fileContents.Length);
                requestStream.Close();

                FtpWebResponse response = (FtpWebResponse)request.GetResponse();

                rp = response.StatusDescription.ToString();

                response.Close();
                requestStream.Close();                
            }
            catch (Exception ex)
            {
                ErrorUpload = "No se pudo realizar la transferencia de archivos al ftp: " + ex.Message.ToString() + " / Status Description: " + rp;             
            }        


        }

        public void UploadStreamIdex(MemoryStream stream, string NombreArchivo, ref string ErrorUpload)
        {
            string userName = WebConfigurationManager.AppSettings["userName_idex"].ToString();
            string passName = WebConfigurationManager.AppSettings["passName_idex"].ToString();
            string ftp = WebConfigurationManager.AppSettings["ftp_idex"].ToString() + NombreArchivo;
            string rp = string.Empty;
            try
            {

                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftp);
                request.Method = WebRequestMethods.Ftp.UploadFile;

                request.Credentials = new NetworkCredential(userName, passName);
                request.UsePassive = true;
                request.UseBinary = true;
                request.KeepAlive = true;
                request.Timeout = 600000;  // 10 minutos

                //StreamReader sourceStream = new StreamReader(stream);
                StreamReader reader = new StreamReader(stream, System.Text.Encoding.UTF8, true);
                byte[] fileContents = Encoding.UTF8.GetBytes(reader.ReadToEnd());
                reader.Close();
                request.ContentLength = fileContents.Length;

                Stream requestStream = request.GetRequestStream();
                requestStream.Write(fileContents, 0, fileContents.Length);
                requestStream.Close();

                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
              
                rp = response.StatusDescription.ToString();

                response.Close();
                requestStream.Close();

            }
            catch (Exception ex)
            {
                ErrorUpload = "No se pudo realizar la transferencia de archivos al ftp: " + ex.Message.ToString() + " / Status Description: " + rp;                 
            }
        }
        
        

       


    }
}
