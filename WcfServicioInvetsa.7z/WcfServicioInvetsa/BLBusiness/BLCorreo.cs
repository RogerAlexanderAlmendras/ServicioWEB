﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using System.Web.Configuration;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using DAccess;
using System.IO;

namespace BLBusiness
{
    public class BLCorreo
    {

        public BERespuesta3 EnvioCorreo_Y_Adjuntos(ref int GeneraTicket, ref int Respuestas, ref int TotalCasos, ref  string AcumuladorMensajes) {
            BERespuesta3 res = new BERespuesta3();
            string tipo = string.Empty;
             

            res = Proceso_EnvioCorreo_Y_Adjuntos("E", ref GeneraTicket, ref AcumuladorMensajes); //generando ticket
            
            //if (res.Codigo == 1)
            //{
            //    return res;
            //}

            res = Proceso_EnvioCorreo_Y_Adjuntos("R", ref Respuestas, ref AcumuladorMensajes); //RESPUESTA

            //if (res.Codigo == 1)
            //{
            //    return res;
            //}

            

            return res;
        }


        public BERespuesta3 Proceso_EnvioCorreo_Y_Adjuntos(string tipo, ref int Cantidad, ref string AcumuladorMensajes)
        {
            List<BEDocumento> Lista = new List<BEDocumento>();
            BERespuesta3 res = new BERespuesta3();
            DACorreo da = new DACorreo();
            BEEmail email = new BEEmail();
            string ErrorCasosEnvioCorreo = string.Empty;
            string ErrorContenidoCorreo = string.Empty;
            string ErrorEnvioEmail = string.Empty;          
            string ErrorActualizarPostEnvioCorreo = string.Empty;
            string Error = string.Empty;

            Lista = da.Proceso_ObtenerCasosEnvioCorreo(tipo, ref Error);
            if (ErrorCasosEnvioCorreo.Length > 0)
            {
                res.Codigo = 1;
                res.Mensaje = Error;
                AcumuladorMensajes = AcumuladorMensajes + " [" + Error + " tipo : " + tipo + "] ";
                return res;
            }

            if (Lista.Count > 0)
            {
                Cantidad = Lista.Count();
            }

            foreach (BEDocumento obj in Lista)
            {
                email.Param = obj.DocEntry.ToString();
                da.Proceso_ObtenerContenidoCorreo(ref email, ref ErrorContenidoCorreo, tipo);
                if (ErrorContenidoCorreo.Length > 0)
                {                    
                    AcumuladorMensajes = AcumuladorMensajes + " [" + ErrorContenidoCorreo + " DocEntry: " + obj.DocEntry + " tipo : " + tipo + "] ";                
                }
                else { 
                    Envio_Correo_Y_Adjuntos(email, ref ErrorEnvioEmail);
                    if (ErrorEnvioEmail.Length > 0)
                    {                        
                        AcumuladorMensajes = AcumuladorMensajes + " [" + ErrorEnvioEmail + " DocEntry: " + obj.DocEntry + " tipo : " + tipo + "] ";                       
                    }
                    else {
                         da.ActualizarPostEnvioCorreo(email, tipo, ref ErrorActualizarPostEnvioCorreo, obj.DocEntry);
                         if (ErrorActualizarPostEnvioCorreo.Length > 0)
                         {                           
                            AcumuladorMensajes = AcumuladorMensajes + " [" + ErrorActualizarPostEnvioCorreo + " DocEntry: " + obj.DocEntry + " tipo : " + tipo + "] ";                           
                        }
                    }
                }
            }             

            return res;
        }

        public void Envio_Correo_Y_Adjuntos(BEEmail email, ref string ErrorEnvioEmail)
        {

            string Contenido = string.Empty;
            string userCredencial = WebConfigurationManager.AppSettings["userCredencial2"].ToString();
            string passCredencial = WebConfigurationManager.AppSettings["passCredencial2"].ToString();
            string host = WebConfigurationManager.AppSettings["host"].ToString();
            int puerto = Convert.ToInt16(WebConfigurationManager.AppSettings["puerto"]);

            try
            {
                SmtpClient client = new SmtpClient();
                client.Port = puerto;
                // utilizamos el servidor SMTP de gmail
                client.Host = host;
                client.EnableSsl = true;
                client.Timeout = 10000000; // (100000 = 100 segundos)
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                // nos autenticamos con nuestra cuenta de gmail
                client.Credentials = new NetworkCredential(userCredencial, passCredencial);

                Contenido = "<table align='left' style='max-width:100%;' width='auto'  height= 'auto'  border= '0px'    >";
                Contenido = Contenido + "<tr><td>";
                Contenido = Contenido + "<h3><p style='color:green;font-family:Sans-serif;margin-left:0.5em;'>Estimado cliente " + email.Cliente + ":  </p></h3> ";
                Contenido = Contenido + "<p style='margin-left:0.5em;'><font face='Sans-serif'>";
                Contenido = Contenido + email.Contenido + "</font><br/><br/>";
                Contenido = Contenido + "Saludos, ";
                Contenido = Contenido + "</p>";
                Contenido = Contenido + "</td></td></tr>";

                Contenido = Contenido + "<tr><td style = 'text-align:right'>";
                Contenido = Contenido + "<img src='cid:imagen2' style = 'max-width:10%;width:auto;height:auto;text-align:right;' />";
                Contenido = Contenido + "</td></tr>";

                Contenido = Contenido + "<tr><td style = 'text-align:left'>";
                Contenido = Contenido + "<img src='cid:imagen' style = 'max-width:60%;width:auto;height:auto;text-align:left;' />";
                Contenido = Contenido + "</td></tr>";

                Contenido = Contenido + "</table><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/> ";

                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(Contenido, Encoding.UTF8, MediaTypeNames.Text.Html);
                // Creamos el recurso a incrustar. Observad

                string FileName = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "imagenes\\FirmaSonia.jpg");
                LinkedResource img = new LinkedResource(FileName, MediaTypeNames.Image.Jpeg);
                img.ContentId = "imagen";
                //Lo incrustamos en la vista HTML...
                htmlView.LinkedResources.Add(img);

                string FileName2 = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "imagenes\\Mverde.png");
                LinkedResource img2 = new LinkedResource(FileName2, MediaTypeNames.Image.Jpeg);
                img2.ContentId = "imagen2";
                htmlView.LinkedResources.Add(img2);


                MailMessage mail = new MailMessage(userCredencial, email.Destino.Replace(';', ','), email.Asunto, Contenido);
                //MailMessage mail = new MailMessage(userCredencial, "sistemas@invetsa.com", email.Asunto, Contenido);


                mail.IsBodyHtml = true;
                mail.BodyEncoding = UTF8Encoding.UTF8;
                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                if (email.Copia.Length > 0)
                {  
                  mail.To.Add(email.Copia.Replace(';', ','));
                //mail.To.Add("wchuco@invetsa.com");
                }
                //string directorio = @"C:\idex\output\";
                //foreach (string file in Directory.EnumerateFiles(pathLocalOutput))
                //{
                //    var nombre = Path.GetFileName(file);
                //    Attachment data = new Attachment(directorio + nombre, MediaTypeNames.Application.Octet);
                //    mail.Attachments.Add(data);
                // }

                //Por último, vinculamos ambas vistas al mensaje...               
                mail.AlternateViews.Add(htmlView);
                client.Send(mail);

            }
            catch (Exception ex)
            {
                ErrorEnvioEmail = ex.Message.ToString();
                //BLCorreo correo = new BLCorreo();
                //ErrorEnvioEmail = ex.Message.ToString();
                //string asunto = "Error: " + System.Reflection.MethodBase.GetCurrentMethod().Name;
                //correo.EnviarCorreoSistemas(asunto, ErrorEnvioEmail);
            }

        }



        public void EnviarCorreoSistemas(string asunto, string Mensaje)
        {
            string passCredencial = WebConfigurationManager.AppSettings["passCredencial"].ToString();
            string host = WebConfigurationManager.AppSettings["host"].ToString();
            string sistemas = WebConfigurationManager.AppSettings["sistemas"].ToString();
            int puerto = Convert.ToInt16(WebConfigurationManager.AppSettings["puerto"]);

            string userCredencial = WebConfigurationManager.AppSettings["userCredencial"].ToString();
            string FechaHoraActual = DateTime.Today.ToString("dd/MM/yyyy");
            string HoraActual = DateTime.Now.ToString("HH:mm:ss");        
            BEEmail email = new BEEmail();
            string Asunto = string.Empty;
            
            Asunto = asunto + " " + FechaHoraActual + " " + HoraActual;
            SmtpClient client = new SmtpClient();
            client.Port = puerto;
            // utilizamos el servidor SMTP de gmail
            client.Host = host;
            client.EnableSsl = true;
            client.Timeout = 10000000; // (100000 = 100 segundos)
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            // nos autenticamos con nuestra cuenta de gmail
            client.Credentials = new NetworkCredential(userCredencial, passCredencial);

            //MailMessage mail = new MailMessage(userCredencial, sistemas, Asunto, Mensaje);
            MailMessage mail = new MailMessage(userCredencial,"ralmendras@invetsa.com", Asunto, Mensaje);
            mail.IsBodyHtml = true;
            mail.BodyEncoding = UTF8Encoding.UTF8;
            mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
            //mail.To.Add(email.Copia);               

            client.Send(mail);


        }

        public void EnviarCorreoYAdjuntos(BEDocumento obj, string AgregarMensajeBody, ref string ErrorEnvioEmail, string AvisoErrorPorCorreo, MemoryStream memStream, string NombreArchivo)
        {
            string passCredencial = WebConfigurationManager.AppSettings["passCredencial"].ToString();
            string host = WebConfigurationManager.AppSettings["host"].ToString();
            int puerto = Convert.ToInt16(WebConfigurationManager.AppSettings["puerto"]);

            string userCredencial = WebConfigurationManager.AppSettings["userCredencial"].ToString();
            string FechaHoraActual = DateTime.Today.ToString("dd/MM/yyyy");
            string HoraActual = DateTime.Now.ToString("HH:mm:ss");
            string asunto = string.Empty;
            BEEmail email = new BEEmail();
            try
            {
                BLTrama bl = new BLTrama();
                email = bl.ObtenerDatosEnvioCorreo(obj);
                if (AvisoErrorPorCorreo.Length > 0)
                {
                    asunto = AvisoErrorPorCorreo + " " + email.Asunto + " " + FechaHoraActual + " " + HoraActual;
                }
                else
                {
                    asunto = email.Asunto + " " + FechaHoraActual + " " + HoraActual;
                }

                string Body = email.Contenido + "<br/>" + AgregarMensajeBody;
                SmtpClient client = new SmtpClient();
                client.Port = puerto;
                // utilizamos el servidor SMTP de gmail
                client.Host = host;
                client.EnableSsl = true;
                client.Timeout = 10000000; // (100000 = 100 segundos)
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                // nos autenticamos con nuestra cuenta de gmail
                client.Credentials = new NetworkCredential(userCredencial, passCredencial);

                MailMessage mail = new MailMessage(userCredencial, email.Destino, asunto, Body);
                mail.IsBodyHtml = true;
                mail.BodyEncoding = UTF8Encoding.UTF8;
                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                if (email.Copia.Length > 0)
                {
                    mail.To.Add(email.Copia);
                }

                if (memStream != null)
                {
                    if (memStream.Length > 0)
                    {
                        byte[] bytes = memStream.ToArray();
                        memStream.Close();
                        mail.Attachments.Add(new Attachment(new System.IO.MemoryStream(bytes), NombreArchivo));
                    }
                }


                client.Send(mail);

            }
            catch (Exception ex)
            {
                ErrorEnvioEmail = ex.Message.ToString();
            }

        }

    }
}
