﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.IO;

namespace Entity
{
    [Serializable]
    [DataContract]
    public class BEMemory
    {
        [DataMember]
        public MemoryStream Memoria  { get; set; }
        [DataMember]
        public string NombreArchivo { get; set; }
    }
}
