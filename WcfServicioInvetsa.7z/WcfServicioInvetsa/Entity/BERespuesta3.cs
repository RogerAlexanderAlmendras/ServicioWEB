﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace Entity
{
    [Serializable]
    [DataContract]
    public class BERespuesta3
    {
        

            [DataMember]
            public int Codigo { get; set; }
            [DataMember]
            public string Mensaje { get; set; }
            [DataMember]
            public int TotalCasos { get; set; }
            [DataMember]
            public int GeneraTicket { get; set; }
            [DataMember]
            public int Respuestas { get; set; }
            

    }
}
