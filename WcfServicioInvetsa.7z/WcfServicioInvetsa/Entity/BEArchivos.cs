﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Entity
{
    public class BEArchivos
    {
        private string ruta;
        private string nombre;
        private string rutaCompleta;

        public string Ruta { get { return ruta; } set { ruta = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }
        public string RutaCompleta { get { return rutaCompleta; } set { rutaCompleta = value; } }

    }
}
