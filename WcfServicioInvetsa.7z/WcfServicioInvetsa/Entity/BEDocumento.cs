﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Entity
{
    [Serializable]
    [DataContract]
    public class BEDocumento
    {
        private int docEntry;
        private int objType;
        private string u_mss_nomarc;

        public int DocEntry { get { return docEntry; } set { docEntry = value; } }
        public int ObjType { get { return objType; } set { objType = value; } }
        public string U_mss_nomarc { get { return u_mss_nomarc; } set { u_mss_nomarc = value; } }
    }
}
