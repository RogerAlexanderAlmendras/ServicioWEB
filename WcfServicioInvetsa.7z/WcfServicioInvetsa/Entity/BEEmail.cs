﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Entity
{
    [Serializable]
    [DataContract]
    public class BEEmail
    {
        [DataMember]
        public string Destino { get; set; }
        [DataMember]
        public string Copia { get; set; }
        [DataMember]
        public string Asunto { get; set; }
        [DataMember]
        public string Contenido { get; set; }
        [DataMember]
        public string Usuario { get; set; }
        [DataMember]
        public string Param { get; set; }
        [DataMember]
        public string Cliente { get; set; }

    }
}
