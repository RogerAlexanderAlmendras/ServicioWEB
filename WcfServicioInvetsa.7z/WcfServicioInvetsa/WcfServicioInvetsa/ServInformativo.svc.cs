﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Entity;
using BLBusiness;
using System.Transactions;


namespace WcfServicioInvetsa
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServInformativo" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione ServInformativo.svc o ServInformativo.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class ServInformativo : IServInformativo
    {
        // codigo = 1 [Error] ,  codigo = 2 [Exito]

        //------------------------------------------------------IDEX-----------------------------------------------------------

       
        public BERespuesta Idex_ArchivosFTP(Parametros1 p)
        {
            BERespuesta rpta = new BERespuesta();
            string AcumuladorMensajes = string.Empty;
            rpta = new BLTrama().Idex_ArchivosFTP(p.FECHA_INI, p.FECHA_FIN);
            
            if (rpta.Codigo == 1 ) {
                BLCorreo correo = new BLCorreo();
                AcumuladorMensajes = rpta.Mensaje;
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
            }

            return rpta;
        }

        //------------------------------------------------------SIGNIA-----------------------------------------------------------

        //Maestros signia
        public BERespuesta Signia_MaestrosFtp_IIMTXT_ESTTXT_RCMTXT_RCMANXTXT()
        {
            BERespuesta rpta = new BERespuesta();
            string AcumuladorMensajes = string.Empty;

            rpta = new BLTrama().Signia_MaestrosFtp();
            if (rpta.Codigo == 1)
            {
                BLCorreo correo = new BLCorreo();
                AcumuladorMensajes = rpta.Mensaje;
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
            }

            return rpta;
        }


        //Nuevo Cliente signia - ESTTXT, RCMTXT, (opcional RCMANXTXT)
      
        public BERespuesta2 Signia_NuevoClienteFtp_ESTTXT_RCMTXT___RCMANXTXT()
        {
            BERespuesta2 res = new BERespuesta2();
            string mensajeSalida = string.Empty;
            string CasosNoGenerados = string.Empty;
            string ErrorListarDocEntry = string.Empty;
            string AcumuladorMensajes = string.Empty;
            
            BLTrama bl = new BLTrama();
            List<BEDocumento> Lista = new List<BEDocumento>();
            int CasosTotales = 0;
            int ArchivosGenerados = 0;
            int indicador = 2;
         
            Lista = bl.ListarDocEntry(indicador, ref ErrorListarDocEntry);
            if (AcumuladorMensajes.Length > 0)
            {
                AcumuladorMensajes = "Error proceso ListarDocEntry : " + AcumuladorMensajes;
            }
            else
            {
                if (Lista.Count() > 0)
                {
                    CasosTotales = Lista.Count();
                }

                foreach (BEDocumento obj in Lista)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {
                        obj.ObjType = indicador;
                        res = new BLTrama().SigniaNuevoClienteFtp(obj, ref ArchivosGenerados, ref CasosNoGenerados, ref AcumuladorMensajes);
                        scope.Complete();
                    }
                }
            }
            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }

            res.ArchivosGenerados = ArchivosGenerados;
            res.CasosNoGenerados = CasosNoGenerados;
            res.CasosTotales = CasosTotales;
            return res;
        }



        //Nuevo Puntos entrega signia - ESTTXT
        
        public BERespuesta2 Signia_NuevoPuntoEntrega_ESTTXT()
        {
            BERespuesta2 res = new BERespuesta2();
            string mensajeSalida = string.Empty;
            string CasosNoGenerados = string.Empty;
            string ErrorListarDocEntry = string.Empty;
            string AcumuladorMensajes = string.Empty;
            BLTrama bl = new BLTrama();
            List<BEDocumento> Lista = new List<BEDocumento>();
            int CasosTotales = 0;
            int ArchivosGenerados = 0;
            int indicador = 21;            

            Lista = bl.ListarDocEntry(indicador, ref ErrorListarDocEntry);
            if (AcumuladorMensajes.Length > 0)
            {
                AcumuladorMensajes = "Error proceso ListarDocEntry : " + AcumuladorMensajes;
            }
            else
            {

                if (Lista.Count() > 0)
                {
                    CasosTotales = Lista.Count();
                }

                foreach (BEDocumento obj in Lista)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {
                        obj.ObjType = indicador;                  
                        res = new BLTrama().SigniaNuevoPuntoEntrega_ESTTXT(obj, ref ArchivosGenerados, ref CasosNoGenerados, ref AcumuladorMensajes);
                        scope.Complete();
                    }
                }
            }
            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }

            res.ArchivosGenerados = ArchivosGenerados;
            res.CasosNoGenerados = CasosNoGenerados;
            res.CasosTotales = CasosTotales;
            return res;
        }



        //Nuevo Producto signia - IIMTXT
        
        public BERespuesta2 Signia_NuevoProducto_IIMTXT()
        {
            BERespuesta2 res = new BERespuesta2();
            string mensajeSalida = string.Empty;
            string CasosNoGenerados = string.Empty;
            string ErrorListarDocEntry = string.Empty;
            string AcumuladorMensajes = string.Empty;
            BLTrama bl = new BLTrama();
            List<BEDocumento> Lista = new List<BEDocumento>();
            int CasosTotales = 0;
            int ArchivosGenerados = 0;
            int indicador = 4;
           
            Lista = bl.ListarDocEntry(indicador, ref AcumuladorMensajes);
            if (AcumuladorMensajes.Length > 0)
            {
                AcumuladorMensajes = "Error proceso ListarDocEntry : " + AcumuladorMensajes;
            }
            else
            {

                if (Lista.Count() > 0)
                {
                    CasosTotales = Lista.Count();
                }

                foreach (BEDocumento obj in Lista)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {
                        obj.ObjType = indicador;                     
                        res = new BLTrama().SigniaNuevoProducto_IIMTXT(obj, ref ArchivosGenerados, ref CasosNoGenerados, ref AcumuladorMensajes);
                        scope.Complete();
                    }
                }
            }
            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }

            res.ArchivosGenerados = ArchivosGenerados;
            res.CasosNoGenerados = CasosNoGenerados;
            res.CasosTotales = CasosTotales;
            return res;
        }



        //INGPRVWTXT: Plantilla de Ingresos por Compra Local o Importación.
        
        public BERespuesta2 Signia_FacturaReservaYOrdenCompra_INGPRVW_18_22()
        {
            BERespuesta2 res = new BERespuesta2();
            string mensajeSalida = string.Empty;
            string CasosNoGenerados = string.Empty;
            string ErrorListarDocEntry = string.Empty;
            string AcumuladorMensajes = string.Empty;
            BLTrama bl = new BLTrama();
            List<BEDocumento> Lista = new List<BEDocumento>();
            int CasosTotales = 0;
            int ArchivosGenerados = 0;
            int indicador = 1822;
            //Lista = bl.ListarDocEntry().Where(m => m.ObjType == 18 || m.ObjType == 22).ToList();//Orden de Venta -- 17 (ord), Orden de Compra -- 22(ingprv), Factura Reserva -- 18(ingprv)          
            //Lista = bl.ListarDocEntry(indicador).Where(m => m.DocEntry == 132477 || m.DocEntry == 132475 || m.DocEntry == 9291 || m.DocEntry == 9305).ToList(); 
            //Lista = bl.ListarDocEntry(indicador).Where(m => m.DocEntry == 132477 || m.DocEntry == 132475).ToList(); 
            Lista = bl.ListarDocEntry(indicador, ref AcumuladorMensajes);
            if (AcumuladorMensajes.Length > 0)
            {
                AcumuladorMensajes = "Error proceso ListarDocEntry : " + AcumuladorMensajes;
            }
            else
            {

                if (Lista.Count() > 0)
                {
                    CasosTotales = Lista.Count();
                }

                foreach (BEDocumento obj in Lista)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {                       
                        res = new BLTrama().PlantillaIngreso_INGPRVW(obj, ref ArchivosGenerados, ref CasosNoGenerados, ref AcumuladorMensajes);
                        scope.Complete();
                    }
                }
            }
            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }


            res.ArchivosGenerados = ArchivosGenerados;
            res.CasosNoGenerados = CasosNoGenerados;
            res.CasosTotales = CasosTotales;
            return res;
        }



        //ORD000025: Plantilla de atención de Pedidos.
       
        public BERespuesta2 Signia_OrdenVenta_ORD000025_17()
        {
            BERespuesta2 res = new BERespuesta2();
            string mensajeSalida = string.Empty;
            string CasosNoGenerados = string.Empty;          
            string AcumuladorMensajes = string.Empty;
            BLTrama bl = new BLTrama();
            List<BEDocumento> Lista = new List<BEDocumento>();
            int CasosTotales = 0;
            int ArchivosGenerados = 0;
            //Lista = bl.ListarDocEntry().Where(m => m.ObjType == 17).ToList();//Orden de Venta -- 17 (ord), Orden de Compra -- 22(ingprv), Factura Reserva -- 18(ingprv)          
            int indicador = 17;        

            Lista = bl.ListarDocEntry(indicador, ref AcumuladorMensajes);
            if (AcumuladorMensajes.Length > 0)
            {
                AcumuladorMensajes = "Error proceso ListarDocEntry : " + AcumuladorMensajes;
            }
            else
            {
                if (Lista.Count() > 0)
                {
                    CasosTotales = Lista.Count();
                }

                foreach (BEDocumento obj in Lista)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {
                        res = new BLTrama().PlantillaAtencionPedidos_ORD(obj, ref ArchivosGenerados, ref CasosNoGenerados, ref AcumuladorMensajes);
                        scope.Complete();                   
                    }
                }
            }
            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }

            res.ArchivosGenerados = ArchivosGenerados;
            res.CasosNoGenerados = CasosNoGenerados;
            res.CasosTotales = CasosTotales;
            return res;
        }


        //ORD000025: Salida de Mercancias
      
        public BERespuesta2 Signia_SalidaMercancias_ORD000025_60()
        {
            BERespuesta2 res = new BERespuesta2();
            string mensajeSalida = string.Empty;
            string CasosNoGenerados = string.Empty;           
            string AcumuladorMensajes = string.Empty;
            BLTrama bl = new BLTrama();
            List<BEDocumento> Lista = new List<BEDocumento>();
            int CasosTotales = 0;
            int ArchivosGenerados = 0;
            int indicador = 60;            

            Lista = bl.ListarDocEntry(indicador, ref AcumuladorMensajes);
            if (AcumuladorMensajes.Length > 0)
            {
                AcumuladorMensajes = "Error proceso ListarDocEntry : " + AcumuladorMensajes;
            }
            else
            {
                if (Lista.Count() > 0)
                {
                    CasosTotales = Lista.Count();
                }

                foreach (BEDocumento obj in Lista)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {                        
                        res = new BLTrama().SalidaMercancias_ORD(obj, ref ArchivosGenerados, ref CasosNoGenerados, ref AcumuladorMensajes);
                        scope.Complete();
                    }
                }
            }
            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }


            res.ArchivosGenerados = ArchivosGenerados;
            res.CasosNoGenerados = CasosNoGenerados;
            res.CasosTotales = CasosTotales;
            return res;
        }



        //ORD000025: Transferencia Stock
       
        public BERespuesta2 Signia_TransferenciaStock_ORD000025_67()
        {
            BERespuesta2 res = new BERespuesta2();
            string mensajeSalida = string.Empty;
            string CasosNoGenerados = string.Empty;          
            string AcumuladorMensajes = string.Empty;           
            BLTrama bl = new BLTrama();
            List<BEDocumento> Lista = new List<BEDocumento>();
            int CasosTotales = 0;
            int ArchivosGenerados = 0;
            int indicador = 67;         

            Lista = bl.ListarDocEntry(indicador, ref AcumuladorMensajes);
            if (AcumuladorMensajes.Length > 0)
            {
                AcumuladorMensajes = "Error proceso ListarDocEntry : " + AcumuladorMensajes;
            }
            else {                 

                if (Lista.Count() > 0)
                {
                    CasosTotales = Lista.Count();
                }
               
                foreach (BEDocumento obj in Lista)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {                      
                        res = new BLTrama().TransferenciaStock_ORD(obj, ref ArchivosGenerados, ref CasosNoGenerados, ref AcumuladorMensajes);
                        scope.Complete();
                    }
                }
            }
            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio:" + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }


            res.ArchivosGenerados = ArchivosGenerados;
            res.CasosNoGenerados = CasosNoGenerados;
            res.CasosTotales = CasosTotales;
            return res;
        }


        public BERespuesta3 EnvioCorreo_Y_Adjuntos()
        {
            BERespuesta3 res = new BERespuesta3();
            int GeneraTicket = 0;
            int Respuestas = 0;
            int TotalCasos = 0;
            string AcumuladorMensajes = string.Empty;          
            res = new BLCorreo().EnvioCorreo_Y_Adjuntos(ref GeneraTicket, ref Respuestas, ref TotalCasos, ref AcumuladorMensajes);
            res.GeneraTicket = GeneraTicket;
            res.Respuestas = Respuestas;
            res.TotalCasos = GeneraTicket + Respuestas;


            if (AcumuladorMensajes.Length > 0)
            {
                BLCorreo correo = new BLCorreo();
                correo.EnviarCorreoSistemas("Errores Servicio: " + System.Reflection.MethodBase.GetCurrentMethod().Name, AcumuladorMensajes);
                res.Mensaje = AcumuladorMensajes;
                res.Codigo = 1;
            }
            else
            {
                res.Mensaje = "Operación completada con éxito";
                res.Codigo = 2;
            }

            return res;
        }


    }
}
