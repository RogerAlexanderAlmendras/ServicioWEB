﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Entity;

namespace WcfServicioInvetsa
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServInformativo" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServInformativo
    {
        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Idex_ArchivosFTP/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta Idex_ArchivosFTP(Parametros1 p);

        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_MaestrosFtp_IIMTXT_ESTTXT_RCMTXT_RCMANXTXT/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta Signia_MaestrosFtp_IIMTXT_ESTTXT_RCMTXT_RCMANXTXT();


        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_NuevoClienteFtp_ESTTXT_RCMTXT___RCMANXTXT/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta2 Signia_NuevoClienteFtp_ESTTXT_RCMTXT___RCMANXTXT();


        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_NuevoPuntoEntrega_ESTTXT/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta2 Signia_NuevoPuntoEntrega_ESTTXT();


        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_NuevoProducto_IIMTXT/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta2 Signia_NuevoProducto_IIMTXT();


        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_FacturaReservaYOrdenCompra_INGPRVW_18_22/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta2 Signia_FacturaReservaYOrdenCompra_INGPRVW_18_22();

        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_OrdenVenta_ORD000025_17/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta2 Signia_OrdenVenta_ORD000025_17();


        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_SalidaMercancias_ORD000025_60/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta2 Signia_SalidaMercancias_ORD000025_60();


        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/Signia_TransferenciaStock_ORD000025_67/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta2 Signia_TransferenciaStock_ORD000025_67();


        [OperationContract()]
        [WebInvoke(Method = "POST", UriTemplate = "/EnvioCorreo_Y_Adjuntos/", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        BERespuesta3 EnvioCorreo_Y_Adjuntos();
    }
}
